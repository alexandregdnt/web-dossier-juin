<!-- Footer -->
<footer class="py-3 bg-dark fixed-bottom">
    <div class="container">
        <p class="m-0 text-center text-white">Copyright &copy; <?= date("Y"); ?> <a href="https://alexgr.be" target="_blank">Alexandre Grodent</a> - Tous droits réservés</p>
    </div>
    <!-- /.container -->
</footer>

<!-- Bootstrap core JavaScript -->
<script src="/assets/vendor/jquery/jquery.min.js"></script>
<script src="/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Plugin JavaScript -->
<script src="/assets/vendor/jquery-easing/jquery.easing.min.js"></script>
</body>
</html>