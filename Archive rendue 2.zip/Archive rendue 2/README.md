# GRODENT Alexandre 2105 - Dossier final Programmation Web dynamique

### Attention lors de la correction de mon dossier !!
Le projet fonctionne correctement uniquement si le nom de domaine pointe vers le sous-dossier `public`.

Afin de faciliter l'utilisation du site, je vous ai fourni dans l'archive le fichier `backup-bdd.sql` qui est une sauvegarde de quelques exemples d'énoncés et de champs.

Attention à bien modifier le fichier `config.json` pour la configuration de la base de données.