<?php
view("index");